/**
 * Processor - the class that processes images.
 * <p>
 * This class manipulats Java BufferedImages, which are effectively 2d arrays
 * of pixels. Each pixel is a single integer packed with 4 values inside it.
 * <p>
 *  Thank you to Mr.Cohen for providing the unpackPixel() and packagePixel() 
 *  methods.
 * 
 * @author James Lu 
 * @version December 2019
 */

import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.WritableRaster;
import java.util.ArrayList;
import greenfoot.*;
import java.awt.Graphics2D;

public class Processor  
{
    //Arraylist to hold a "history" of changes.
    public static ArrayList<BufferedImage> changes = new ArrayList<BufferedImage>();
    /**
     * Example colour altering method by Mr. Cohen. This method will
     * increase the blue value while reducing the red and green values.
     * 
     * Demonstrates use of packagePixel() and unpackPixel() methods.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void blueify (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the image Blue-er
                if(blue<250){blue += 5;}else{blue = 255;}
                if(red>50){red -= 5;}else if (red>46){red = 46;}
                if(green>50){green -= 5;}else if(green>46){green = 46;}

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Similar to blueify, except with green.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    
    public static void greenify (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the image Green-er
                if(green<250){green += 5;}else{green = 255;}
                if(red>50){red -= 5;}else if (red>46){red = 46;}
                if(blue>50){blue -= 5;}else if(blue>46){blue = 46;}

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Similar to blueify, except with red.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void redify (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the image Red-er
                if(red<250){red += 5;}else{red = 255;}
                if(blue>50){blue -= 5;}else if (blue>46){blue = 46;}
                if(green>50){green -= 5;}else if(green>46){green = 46;}

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Makes the image look warmer, by incresing the red and green values
     * of each pixel, while keeping the blues the same.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void warm (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the image warmer
                if(red<250){red += 5;}else{red = 255;}
                if(green<250){green += 5;}else{green = 255;}

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Makes the image look cooler, by decreasing the red and green values of
     * each pixel, while keeping blue the same.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void cool (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the image warmer
                if(red>50){red -= 5;}else if(red>46){red = 46;}
                if(green>50){green -= 5;}else if(green>46){green = 46;}

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Makes the image darker, by dereasing red, green, and blue values of each
     * pixel, while keeping the ratio the same.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void darken (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                //Make the pic darker, by decreasing each of the RGB values, while keeping the ratio the same
                blue /= 1.02;
                red /= 1.02;
                green /= 1.02;

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Makes the image brighter, by increasing red, green, and blue values of each
     * pixel, while keeping the ratio the same.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void brighten (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));

        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];

                // make the pic brighter, by increasing each of the RGB values, while keeping the ratio the same
                if(blue <= 250){
                    blue *= 1.02;
                }
                else
                {
                    blue = 255;
                }
                if(red <= 250){
                    red *= 1.02;
                }
                else
                {
                    red = 255;
                }
                if(green <= 250){
                    green *= 1.02;
                }
                else
                {
                    green = 255;
                }
                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Sets the red value of each pixel to green, green to blue, and blue to red
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void cycle (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));

        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];
                //cycle the RGB values
                red = rgbValues[2];
                green = rgbValues[3];
                blue = rgbValues[1];

                int newColour = packagePixel (red, green, blue, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Changes the image to grayscale, by making the red, green, and blue values
     * for each pixel the same, based on their original values.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void grayscale (BufferedImage bi)
    { 
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight(); 
        changes.add(deepCopy(bi));

        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];
                //Creates gray value using a formula I found on TutorialsPoint
                double gray = (0.3 * red) + (0.59 * green) + (0.11 * blue);
                gray = (int)gray;

                int newColour = packagePixel ((int)gray, (int)gray, (int)gray, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Similar to grayscale, but it then sets the colour of each pixel to either
     * white, black, or gray-50%, based on what the original colour was closest to.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void charcoal (BufferedImage bi)
    { 
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight(); 
        changes.add(deepCopy(bi));

        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];
                //Same formula
                double gray = (0.3 * red) + (0.59 * green) + (0.11 * blue);
                gray = (int)gray;
                //Sets gray to one of three values, based on which it was closest to
                if (gray < 76)
                {
                    //black
                    gray = 0;
                }
                else if(gray > 75 && gray < 176)
                {
                    //gray-50%
                    gray = 128;
                }
                else if(gray > 175)
                {
                    //white
                    gray = 255;
                }

                int newColour = packagePixel ((int)gray, (int)gray, (int)gray, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Also similar to grayscale, but it then sets the colour of each pixel to either
     * white, black, based on what the original colour was closest to.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void blackWhite (BufferedImage bi)
    { 
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight(); 
        changes.add(deepCopy(bi));

        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];
                //Same formula
                double gray = (0.3 * red) + (0.59 * green) + (0.11 * blue);
                //Same idea
                gray = (int)gray;
                if (gray < 126)
                {
                    //black
                    gray = 0;
                }
                else 
                {
                    //white
                    gray = 255;
                }
                int newColour = packagePixel ((int)gray, (int)gray, (int)gray, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Sets the new colour of each pixel to the opposite of what is used to be,
     * creating a negative image of the original.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void negative (BufferedImage bi)
    {
        // Get image size to use in for loops
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Using array size as limit
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                // Calls method in BufferedImage that returns R G B and alpha values
                // encoded together in an integer
                int rgb = bi.getRGB(x, y);

                // Call the unpackPixel method to retrieve the four integers for
                // R, G, B and alpha and assign them each to their own integer
                int[] rgbValues = unpackPixel (rgb);

                int alpha = rgbValues[0];
                int red = rgbValues[1];
                int green = rgbValues[2];
                int blue = rgbValues[3];
                
                //Integers for the opposite colours
                int r = 255 - red;
                int g = 255 - green;
                int b = 255 - blue;

                int newColour = packagePixel (r, g, b, alpha);
                bi.setRGB (x, y, newColour);
            }
        }
    }
    /**
     * Flips the original image horizontally 
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void flipHorizontal (BufferedImage bi)
    {
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Temp image, to store pixels as we reverse everything
        BufferedImage newBi = new BufferedImage (xSize, ySize, 3);
        
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                int rgb = bi.getRGB(x, y);
                newBi.setRGB (xSize - x - 1, y, rgb);
            }
        }
        //Changes original image to the Temp image
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++) 
            {
                int rgb = newBi.getRGB(x, y);
                bi.setRGB (x, y, rgb);
            }
        }
    }
    /**
     * Flips the original image Vertically
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void flipVertical (BufferedImage bi)
    {
        int xSize = bi.getWidth();
        int ySize = bi.getHeight();
        changes.add(deepCopy(bi));
        // Temp image, to store pixels as we reverse everything
        BufferedImage newBi = new BufferedImage (xSize, ySize, 3);

        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                int rgb = bi.getRGB(x, y);
                newBi.setRGB (x, ySize-y-1, rgb);
            }
        }
        //Changes original image to the Temp image
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                int rgb = newBi.getRGB(x, y);
                bi.setRGB (x, y, rgb);
            }
        }
    }
    /**
     * Undoes the last modification to the image, using ArrayLists.
     * 
     * @param bi    The BufferedImage (passed by reference) to change.
     */
    public static void undo(BufferedImage bi)
    {
        //size of the previous image
        int xSize = (changes.get(changes.size() - 1)).getWidth();
        int ySize = (changes.get(changes.size() - 1)).getHeight();
        // Temp image, to store pixels as we undo everything
        BufferedImage newBi = new BufferedImage(xSize,ySize,3);
        //Changes Temp image to the previous image
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                int rgb = (changes.get(changes.size() - 1)).getRGB(x, y);
                newBi.setRGB (x, y, rgb);
            } 
        } 
        //Changes original image to the Temp image
        for (int x = 0; x < xSize; x++)
        {
            for (int y = 0; y < ySize; y++)
            {
                int rgb = newBi.getRGB(x, y);
                bi.setRGB (x, y, rgb);
            } 
        }
        //Removes the now current image from the Arraylist.
        changes.remove(changes.size() - 1);
    }
    /**
     * Creates a new BufferedImage that is a 90 degree clockwise rotation of 
     * the current image, then returns it as a GreenfootImage.
     * 
     * @param bi    The BufferedImage (passed by reference) to use as reference.
     * 
     * @return GreenfootImage The GreenfootImage that is a rotation of the original BufferedImage.
     */ 
    public static GreenfootImage rotate (BufferedImage bi)
    {
        int xSize = bi.getHeight();
        int ySize = bi.getWidth();
        changes.add(deepCopy(bi));
        // BufferedImage that will be convereted to a GreenfootImage
        BufferedImage newBi = new BufferedImage (xSize, ySize, 3);
        //Makes it a 90 degree rotation of the original 
        for (int y = 0; y < ySize; y++)
        {
            for (int x = 0; x < xSize; x++)
            {
                int rgb = bi.getRGB(y,bi.getHeight()-x-1);
                newBi.setRGB (x, y, rgb);
            }
        }
        return createGreenfootImageFromBI(newBi);
    }
    /**
     * Code provided by Mr.Cohen to be used for the undo feature
     */
    public static BufferedImage deepCopy(BufferedImage bi) 
    {
        ColorModel cm = bi.getColorModel();
        boolean isAlphaPremultip = cm.isAlphaPremultiplied();
        WritableRaster raster = bi.copyData(null);
        return new BufferedImage(cm, raster, isAlphaPremultip, null);
    }    

    /**
     * Takes in a BufferedImage and returns a GreenfootImage.
     *
     * @param newBi The BufferedImage to convert.
     *
     * @return GreenfootImage A GreenfootImage built from the BufferedImage provided.
     */
    public static GreenfootImage createGreenfootImageFromBI (BufferedImage newBi)
    {
        GreenfootImage returnImage = new GreenfootImage (newBi.getWidth(), newBi.getHeight());
        BufferedImage backingImage = returnImage.getAwtImage();
        Graphics2D backingGraphics = (Graphics2D)backingImage.getGraphics();
        backingGraphics.drawImage(newBi, null, 0, 0);
        return returnImage;

    }

    

    /**
     * Takes in an rgb value - the kind that is returned from BufferedImage's
     * getRGB() method - and returns 4 integers for easy manipulation.
     * 
     * By Jordan Cohen
     * Version 0.2
     * 
     * @param rgbaValue The value of a single pixel as an integer, representing<br>
     *                  8 bits for red, green and blue and 8 bits for alpha:<br>
     *                  <pre>alpha   red     green   blue</pre>
     *                  <pre>00000000000000000000000000000000</pre>
     * @return int[4]   Array containing 4 shorter ints<br>
     *                  <pre>0       1       2       3</pre>
     *                  <pre>alpha   red     green   blue</pre>
     */
    public static int[] unpackPixel (int rgbaValue)
    {
        int[] unpackedValues = new int[4];
        // alpha
        unpackedValues[0] = (rgbaValue >> 24) & 0xFF;
        // red
        unpackedValues[1] = (rgbaValue >> 16) & 0xFF;
        // green
        unpackedValues[2] = (rgbaValue >>  8) & 0xFF;
        // blue
        unpackedValues[3] = (rgbaValue) & 0xFF;

        return unpackedValues;
    }

    /**
     * Takes in a red, green, blue and alpha integer and uses bit-shifting
     * to package all of the data into a single integer.
     * 
     * @param   int red value (0-255)
     * @param   int green value (0-255)
     * @param   int blue value (0-255)
     * @param   int alpha value (0-255)
     * 
     * @return int  Integer representing 32 bit integer pixel ready
     *              for BufferedImage
     */
    public static int packagePixel (int r, int g, int b, int a)
    {
        int newRGB = (a << 24) | (r << 16) | (g << 8) | b;
        return newRGB;
    }
}
