import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.io.File;
import javax.swing.JOptionPane;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;
/**
 * This is a program that allows the user to open a picture and modify is
 * using various transformations, filters, and colours. The finished product
 * can then be saved 
 * 
 * The class Processor contains all of the code to actually perform
 * transformation. The rest of the classes serve to support that
 * capability. This World allows the user to choose transformations,
 * open files, and save files.
 * 
 * The logo and min/max/close buttons in the corners are just for decoration - 
 * they have no function. 
 * 
 * Thank you to Mr.Cohen for providing the starter code and methods.
 * 
 * @author James Lu
 * @version December 2019
 */
public class Background extends World
{
    // Constants:
    private final String STARTING_FILE = "Shark.jpg";

    // Objects and Variables:
    private ImageHolder image;

    private TextButton openFile;
    private TextButton transformationsButton;
    private TextButton filtersButton;
    private TextButton coloursButton;
    private TextButton vRevButton;
    private TextButton hRevButton;
    private TextButton rotateButton;
    private TextButton rotateButton2;
    private TextButton grayscaleButton;
    private TextButton bwButton;
    private TextButton charcoalButton;
    private TextButton negativeButton;
    private TextButton cycleButton;
    private TextButton brightButton;
    private TextButton darkButton;
    private TextButton redButton;
    private TextButton greenButton;
    private TextButton blueButton;
    private TextButton warmButton;
    private TextButton coolButton;
    private TextButton undoButton;
    private TextButton saveButton;
    private String fileName;

    /**
     * Constructor for objects of class Background.
     * 
     */
    public Background()
    {    
        super(960,640, 1); 

        // Initialize tabs and the image
        image = new ImageHolder(STARTING_FILE);

        hRevButton = new TextButton("       Flip Horizontal       ");
        vRevButton = new TextButton("         Flip Vertical          ");
        rotateButton = new TextButton("            Rotate 90            ");
        rotateButton2 = new TextButton("           Rotate 180           ");
        grayscaleButton = new TextButton("           Grayscale           ");
        bwButton = new TextButton("         Black+White         ");
        charcoalButton = new TextButton("            Charcoal            ");
        negativeButton = new TextButton("            Negative            ");
        cycleButton = new TextButton("          CycleRGB            ");
        brightButton = new TextButton("           Brighten             ");
        darkButton = new TextButton("             Darken              ");
        redButton = new TextButton("             Red-ify              ");
        greenButton = new TextButton("           Green-ify            ");
        blueButton = new TextButton("            Blue-ify              ");
        warmButton = new TextButton("               Warm               ");
        coolButton = new TextButton("                Cool                ");
        undoButton = new TextButton("     Undo     ");
        saveButton = new TextButton("     Save     ");
        openFile = new TextButton  ("     Open     ");
        transformationsButton = new TextButton("  Transformations  ");
        filtersButton = new TextButton        ("         Filters         ");
        coloursButton = new TextButton        ("         Colours         ");
        // Add objects to the screen 
        addObject (image, 365,350);
        addObject (transformationsButton, 938, 140);
        transformationsButton.setRotation(90);
        addObject (filtersButton, 938, 280); 
        filtersButton.setRotation(90);
        addObject (coloursButton, 938, 420);
        coloursButton.setRotation(90);
        addObject (openFile, 150, 30);
        addObject (saveButton, 250, 30);
        addObject (undoButton, 350, 30);
    }

    /**
     * Act() method just checks for mouse input
     */
    public void act ()
    {
        checkMouse();
    }

    /**
     * Check for user clicking on a button
     */
    private void checkMouse ()
    {
        // Avoid excess mouse checks - only check mouse if somethething is clicked.
        if (Greenfoot.mouseClicked(null))
        {
            if(Greenfoot.mouseClicked(transformationsButton)){
                //remove buttons from other tabs, add the one in this tab
                removeObject(grayscaleButton);
                removeObject(charcoalButton);
                removeObject(bwButton);
                removeObject(negativeButton);
                removeObject(warmButton);
                removeObject(coolButton);
                removeObject(redButton);
                removeObject(greenButton);
                removeObject(blueButton);
                removeObject(cycleButton);
                removeObject(brightButton);
                removeObject(darkButton);

                addObject (hRevButton, 825, 90);
                addObject (vRevButton, 825, 130);
                addObject (rotateButton, 825, 170);
                addObject (rotateButton2, 825, 210);
                transformationsButton.update("  Transformations  ", true);
                coloursButton.update("         Colours         ", false);
                filtersButton.update("         Filters         ", false);
            }
            else if(Greenfoot.mouseClicked(filtersButton)){
                //remove buttons from other tabs, add the one in this tab
                removeObject(hRevButton); 
                removeObject(vRevButton); 
                removeObject(rotateButton); 
                removeObject(rotateButton2); 
                removeObject(redButton);
                removeObject(greenButton);
                removeObject(blueButton);
                removeObject(cycleButton);
                removeObject(brightButton);
                removeObject(darkButton);

                addObject (grayscaleButton, 825, 90);
                addObject (charcoalButton, 825, 130);
                addObject (bwButton, 825, 170);
                addObject (negativeButton, 825, 210);
                addObject (warmButton, 825, 250);
                addObject (coolButton, 825, 290);
                filtersButton.update("         Filters         ", true);
                transformationsButton.update("  Transformations  ", false);
                coloursButton.update("         Colours         ", false);
            }
            else if(Greenfoot.mouseClicked(coloursButton)){
                //remove buttons from other tabs, add the one in this tab
                removeObject(hRevButton); 
                removeObject(vRevButton); 
                removeObject(rotateButton); 
                removeObject(rotateButton2);
                removeObject(grayscaleButton);
                removeObject(charcoalButton);
                removeObject(bwButton);
                removeObject(negativeButton);
                removeObject(warmButton);
                removeObject(coolButton);
                addObject (redButton, 825, 90);
                addObject (greenButton, 825, 130);
                addObject (blueButton, 825, 170);
                addObject (cycleButton, 825, 210);
                addObject (brightButton, 825, 250);
                addObject (darkButton, 825, 290);
                coloursButton.update("         Colours         ", true);
                transformationsButton.update("  Transformations  ", false);
                filtersButton.update("         Filters         ", false);
            }
            else if (Greenfoot.mouseClicked(blueButton)){
                Processor.blueify(image.getBufferedImage());  
            }
            else if (Greenfoot.mouseClicked(redButton)){
                Processor.redify(image.getBufferedImage());  
            }
            else if (Greenfoot.mouseClicked(greenButton)){
                Processor.greenify(image.getBufferedImage());  
            }
            else if (Greenfoot.mouseClicked(hRevButton)){
                Processor.flipHorizontal(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(vRevButton)){
                Processor.flipVertical(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(rotateButton)){
                GreenfootImage temp = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                image.setImage(temp);
            }
            else if (Greenfoot.mouseClicked(rotateButton2)){
                //Rotates image twice 
                GreenfootImage temp = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                image.setImage(temp);
                GreenfootImage temp2 = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                image.setImage(temp2);
                //To treat this as one modification when using undo
                Processor.changes.remove(Processor.changes.size()-1);
            }
            else if (Greenfoot.mouseClicked(grayscaleButton)){
                Processor.grayscale(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(bwButton)){
                Processor.blackWhite(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(charcoalButton)){
                Processor.charcoal(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(negativeButton)){
                Processor.negative(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(cycleButton)){
                Processor.cycle(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(brightButton)){
                Processor.brighten(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(darkButton)){
                Processor.darken(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(warmButton)){
                Processor.warm(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(coolButton)){
                Processor.cool(image.getBufferedImage());
            }
            else if (Greenfoot.mouseClicked(undoButton)){
                if(Processor.changes.size()>0)
                {
                    //checks if the last modification was a rotation
                    if(image.getImage().getWidth() != Processor.changes.get(Processor.changes.size() - 1).getWidth())
                    {
                        //rotates the image 3 times
                        GreenfootImage temp = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                        image.setImage(temp);
                        GreenfootImage temp2 = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                        image.setImage(temp2);
                        GreenfootImage temp3 = new GreenfootImage(Processor.rotate(image.getBufferedImage()));
                        image.setImage(temp3);
                        //removes the BufferedImages just stored from those rotations
                        for(int i = 0; i < 4; i++)
                        {
                            Processor.changes.remove(Processor.changes.size() - 1);
                        }
                    }
                    else
                    {
                        Processor.undo(image.getBufferedImage()); 
                    }
                }
            } 
            else if (Greenfoot.mouseClicked(saveButton)){
                savePng();
            }
            else if (Greenfoot.mouseClicked(openFile))
            {
                openFile ();
            }
        }
    }

    /**
     * Allows the user to open a new image file.
     */
    private void openFile ()
    { 
        // Use a JOptionPane to get file name from user
        String fileName = JOptionPane.showInputDialog("Please input a file name with extension");
        // If the file opening operation is successful, update the text in the open file button
        if (image.openFile (fileName))
        {
            String display = "     Open     ";
            openFile.update (display,false);
            while(Processor.changes.size()>0)
            {
                Processor.changes.remove(0);
            }
        }
    }

    /**
     * Saves the current image as a Png, some code provided by Mr.Cohen.
     */  
    private void savePng()
    {
        //Asks user for the desired image name
        String fileName = JOptionPane.showInputDialog("Input a file name(No extension)");
        fileName += ".png";
        try
        {
            File f = new File (fileName);
            ImageIO.write(image.getBufferedImage(), "png", f);
            System.out.println("Save Successful");
        }
        catch(IOException e)
        {
            System.out.println("Please Try Again");
        }
    }
}

